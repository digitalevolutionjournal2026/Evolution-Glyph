/**
 * motion-tokens.ts
 * ------------------------------------------------------------------
 * Single source of truth for every color, easing curve, spring
 * preset and duration used across the Evolution Glyph motion
 * system. Nothing below should be hand-authored again inside a
 * component — import from here so the whole system stays coherent
 * if the brand evolves.
 */

import type { Transition } from "framer-motion";

/* ------------------------------------------------------------------
 * COLOR — named, not inline. Matches the supplied reference mark:
 * cyan → blue on the left ribbon, indigo → violet → light orchid
 * on the right ribbon, with a cool-white core star.
 * ---------------------------------------------------------------- */
export const glyphColor = {
  cyan: "#22D3EE",
  blue: "#3B82F6",
  indigo: "#6366F1",
  violet: "#8B5CF6",
  orchid: "#C084FC",
  starCore: "#F5F9FF",
  starGlow: "#93C5FD",
  ink: "#05060A",
  achievementGold: "#FBBF24",
  errorEmber: "#F97373",
} as const;

/* ------------------------------------------------------------------
 * EASING — premium cubic-béziers only. No default CSS easing
 * anywhere in this system (linear, ease, ease-in-out are banned).
 * ---------------------------------------------------------------- */
export const ease = {
  /** Apple-marketing style: long, confident deceleration. Use for
   *  anything arriving at rest — settle, lock-in, reassembly. */
  appleOut: [0.16, 1, 0.3, 1] as const,
  /** Linear.app-style symmetric snap. Use for state-to-state
   *  transitions that need to feel immediate but not abrupt. */
  linearSnap: [0.65, 0, 0.35, 1] as const,
  /** Soft in-out for slow, ambient, looping motion (breathing,
   *  floating, glow pulse). */
  ambient: [0.45, 0, 0.55, 1] as const,
  /** Sharp entry, soft exit — for things that should feel like
   *  they're being pulled into existence (spark ignition). */
  emerge: [0.11, 0.9, 0.2, 1] as const,
} as const;

/* ------------------------------------------------------------------
 * SPRINGS — physical, not curve-based. Reserved for state changes
 * that should feel like they have mass (assembly, celebration).
 * ---------------------------------------------------------------- */
export const spring = {
  gentle: { type: "spring", stiffness: 120, damping: 20, mass: 1 } as Transition,
  settle: { type: "spring", stiffness: 170, damping: 26, mass: 0.9 } as Transition,
  snap: { type: "spring", stiffness: 320, damping: 24, mass: 0.7 } as Transition,
  bouncy: { type: "spring", stiffness: 380, damping: 14, mass: 0.6 } as Transition,
} as const;

/* ------------------------------------------------------------------
 * DURATIONS (seconds) — every duration in the system traces back
 * to one of these so timing stays a design decision, not a guess
 * scattered across files.
 * ---------------------------------------------------------------- */
export const duration = {
  breathe: 5.2, // idle inhale/exhale cycle
  float: 6.4, // idle vertical drift cycle
  glowPulseIdle: 4.8,
  starTwinkle: 3.6,
  thinkingPulse: 1.6,
  thinkingOrbit: 8,
  success: 0.5,
  error: 0.4,
  celebration: 1.1,
  achievement: 1.4,
  transitionBreak: 0.42,
  transitionTravel: 0.5,
  transitionReassemble: 0.42,
  hoverLift: 0.32,
} as const;

/* ------------------------------------------------------------------
 * LOADING TIMELINE (milliseconds) — lifted verbatim from spec.
 * Spark → Awareness → Reflection → Growth → Transformation →
 * Glyph lock → Glow pulse → hand-off to navbar position.
 * ---------------------------------------------------------------- */
export const loadingTimeline = {
  sparkAppear: [0, 200],
  sparkGrow: [200, 400],
  particlesOrbit: [400, 700],
  segmentsFlyIn: [700, 900],
  glyphLock: [900, 1200],
  glowPulse: [1200, 1500],
  handoff: 1500,
} as const;

/** Reduced-motion transition: opacity/color only, no transform,
 *  no spring overshoot. Every animated part must have one. */
export const reducedTransition: Transition = {
  duration: 0.25,
  ease: "linear" as const,
};
