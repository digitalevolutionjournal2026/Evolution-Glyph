/**
 * microInteractions.ts
 * ------------------------------------------------------------------
 * The brief requires buttons, cards, dialogs, AI responses and
 * dashboard widgets to "all inherit the same motion language" as
 * the glyph. Concretely, that means: the same easing curves, the
 * same spring presets, and the same restraint (small translations,
 * no bounce-for-bounce's-sake) — not literal glyph animation
 * borrowed onto unrelated shapes.
 *
 * These are plain Framer Motion prop objects — spread them onto
 * any motion.* element:
 *
 *   <motion.button {...hoverLift}>Save</motion.button>
 *   <motion.div {...cardEnter}>...</motion.div>
 */
import type { MotionProps } from "framer-motion";
import { duration, ease, spring } from "./motion-tokens";

/** Soft magnetic hover + lift, mirroring the glyph's own hover
 *  behavior. Use on buttons, nav items, interactive cards. */
export const hoverLift: MotionProps = {
  whileHover: { y: -2, scale: 1.015, transition: { duration: duration.hoverLift, ease: ease.appleOut } },
  whileTap: { scale: 0.985, transition: { duration: 0.12, ease: ease.linearSnap } },
};

/** Card / list-item entrance: settles into place, never slides in
 *  from an arbitrary offscreen direction. */
export const cardEnter: MotionProps = {
  initial: { opacity: 0, y: 8, scale: 0.98 },
  animate: { opacity: 1, y: 0, scale: 1 },
  transition: spring.settle,
};

/** Dialog / modal entrance — slightly snappier than a card since
 *  it's a direct response to a user action. */
export const dialogEnter: MotionProps = {
  initial: { opacity: 0, scale: 0.96, y: 6 },
  animate: { opacity: 1, scale: 1, y: 0 },
  exit: { opacity: 0, scale: 0.98, transition: { duration: 0.18, ease: ease.linearSnap } },
  transition: spring.snap,
};

/** AI response bubble — arrives the way the glyph's "success"
 *  state resolves: a small settle, not a slide or bounce. */
export const aiResponseEnter: MotionProps = {
  initial: { opacity: 0, y: 6 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.32, ease: ease.appleOut },
};

/** Dashboard widget — same settle spring as cardEnter, but with a
 *  staggerable delay slot for grids of widgets. */
export function dashboardWidget(index = 0): MotionProps {
  return {
    initial: { opacity: 0, y: 10 },
    animate: { opacity: 1, y: 0 },
    transition: { ...spring.settle, delay: index * 0.04 },
  };
}
