/**
 * types.ts
 * ------------------------------------------------------------------
 * Shared types for the Evolution Glyph motion system.
 */

/** Every behavioral state the glyph can be in. `hidden` is a real
 *  state (not `display:none`) so it can be entered/exited with
 *  the same transition language as everything else. */
export type GlyphState =
  | "idle"
  | "loading"
  | "thinking"
  | "transition"
  | "success"
  | "error"
  | "celebration"
  | "achievement"
  | "hidden";

export interface EvolutionGlyphProps {
  /** Current behavioral state. Defaults to "idle". */
  state?: GlyphState;
  /** Rendered size in px (square). Defaults to 96. */
  size?: number;
  /** Extra className passed to the outer wrapper. */
  className?: string;
  /** Accessible label. The glyph is decorative by default
   *  (aria-hidden); pass this to expose it as a meaningful image
   *  (e.g. when it's the only content of a button). */
  ariaLabel?: string;
  /** Called when a one-shot state (loading / success / error /
   *  celebration / achievement / transition) finishes its
   *  animation and would naturally return to idle. */
  onStateComplete?: (state: GlyphState) => void;
  /** Shared layoutId for magic-move handoff between the splash
   *  loader, the navbar logo and page transitions. Only one glyph
   *  instance on screen should own a given layoutId at a time. */
  layoutId?: string;
  /** Forces reduced motion regardless of OS setting. Primarily
   *  for storybook/testing; production should rely on the OS
   *  preference detected by useReducedMotionPreference. */
  forceReducedMotion?: boolean;
}

export interface ParticleSystemProps {
  /** Which glyph state is driving the particle behavior. */
  state: GlyphState;
  /** Number of particles. Keep low — this is an accent, not a
   *  fireworks display. */
  count?: number;
  /** Orbit / scatter radius in local SVG units. */
  radius?: number;
  /** Respect reduced motion — disables orbit, keeps a static
   *  faint scatter instead. */
  reducedMotion?: boolean;
}

export interface GlowLayerProps {
  /** Whether the glow is actively pulsing/expanding. */
  active: boolean;
  /** CSS color (hex/rgb) for the glow. */
  color: string;
  /** Base size in px of the glow's bounding box. */
  size: number;
  /** 0–1 baseline intensity before animation multiplies it. */
  intensity?: number;
  reducedMotion?: boolean;
}
