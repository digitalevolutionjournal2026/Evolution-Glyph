"use client";

import { useEffect } from "react";
import { motion, type Variants } from "framer-motion";
import { duration, ease, glyphColor, reducedTransition, spring } from "../lib/motion-tokens";
import type { EvolutionGlyphProps } from "../lib/types";
import { useReducedMotionPreference } from "../hooks/useReducedMotionPreference";
import { GlowLayer } from "./GlowLayer";
import { ParticleSystem } from "./ParticleSystem";

/* ------------------------------------------------------------------
 * GEOMETRY
 * ------------------------------------------------------------------
 * The mark is a diamond ribbon-frame built from two straight-edged
 * bands (a picture-frame diamond, split at two seams) plus a
 * curling tail flourish and a four-point center star. Geometry is
 * derived from a diamond of outer half-diagonal 100 and inner
 * half-diagonal 60, centered at (120,120) in a 240x240 viewBox —
 * chosen to keep the ribbon's proportions and the "geometric,
 * faceted" language of the reference mark rather than redesigning
 * it into rounded blobs.
 *
 * NOTE: this is a faithful *approximation* built from geometric
 * construction, not a pixel trace of the supplied artwork. Swap
 * the `d` attributes below with an exported vector trace of the
 * original file if pixel-parity with the source PNG is required.
 * ---------------------------------------------------------------- */
const BLUE_RIBBON_PATH = "M120,20 L20,120 L70,170 L90,150 L60,120 L120,60 Z";
const PURPLE_RIBBON_PATH = "M70,170 L120,220 L220,120 L120,20 L120,60 L180,120 L120,180 L90,150 Z";
const TOP_FOLD_PATH = "M120,20 L104,52 L120,58 L136,52 Z";
const TAIL_FLOURISH_PATH = "M150,196 C176,206 188,176 168,154 C152,140 130,150 130,166";
const STAR_PATH =
  "M120,94 C122,110 130,118 146,120 C130,122 122,130 120,146 C118,130 110,122 94,120 C110,118 118,110 120,94 Z";

const VIEWBOX_SIZE = 240;

/* ------------------------------------------------------------------
 * VARIANTS — one object per glyph part, one key per GlyphState.
 * Keeping all seven states side-by-side per part (rather than
 * scattering conditionals through JSX) is what makes it possible
 * to audit "does every state have a deliberate value for every
 * part" at a glance.
 * ---------------------------------------------------------------- */

const containerVariants: Variants = {
  idle: {
    y: [0, -4, 0],
    scale: [1, 1.015, 1],
    rotate: [0, 1.1, 0, -1.1, 0], // well under the 2°/s ceiling
    transition: { duration: duration.float, ease: ease.ambient, repeat: Infinity },
  },
  loading: { y: 0, scale: 1, rotate: 0, transition: spring.settle },
  thinking: {
    y: [0, -2, 0],
    scale: 1,
    rotate: 0,
    transition: { duration: duration.thinkingPulse * 1.4, ease: ease.ambient, repeat: Infinity },
  },
  transition: { y: 0, scale: 0.92, rotate: 0, transition: { duration: duration.transitionBreak, ease: ease.linearSnap } },
  success: { y: [0, -6, 0], scale: [1, 1.08, 1], rotate: 0, transition: { duration: duration.success, ease: ease.appleOut } },
  error: {
    x: [0, -3, 3, -2, 2, 0],
    y: 0,
    scale: 1,
    rotate: 0,
    transition: { duration: duration.error, ease: ease.linearSnap },
  },
  celebration: {
    y: [0, -10, 0],
    scale: [1, 1.12, 1],
    rotate: [0, -3, 3, 0],
    transition: { duration: duration.celebration, ease: ease.appleOut },
  },
  achievement: {
    y: [0, -5, 0],
    scale: [1, 1.06, 1],
    rotate: [0, 4, 0],
    transition: { duration: duration.achievement, ease: ease.appleOut },
  },
  hidden: { opacity: 0, scale: 0.85, transition: reducedTransition },
};

const blueRibbonVariants: Variants = {
  idle: { opacity: 1, filter: "brightness(1)" },
  // "Segments fly together" (700–900ms of the loading timeline): the
  // ribbon arrives as a transform, not a stroke draw-in — pathLength
  // only affects stroked paths, and this shape is filled, so a real
  // fly-in has to move the shape itself.
  loading: {
    opacity: [0, 1],
    x: [-34, 0],
    y: [-22, 0],
    rotate: [-14, 0],
    transition: { duration: 0.28, ease: ease.emerge, delay: 0.7 },
  },
  thinking: { opacity: [0.85, 1, 0.85], transition: { duration: duration.thinkingPulse, repeat: Infinity, ease: ease.ambient } },
  transition: { opacity: 0, x: -18, y: -10, transition: { duration: duration.transitionBreak, ease: ease.linearSnap } },
  success: { opacity: 1, filter: "brightness(1.15)" },
  error: { opacity: 1, x: [0, -6, 4, 0], transition: { duration: duration.error, ease: ease.linearSnap } },
  celebration: { opacity: 1, filter: "brightness(1.2)" },
  achievement: { opacity: 1, filter: "brightness(1.1)" },
  hidden: { opacity: 0 },
};

const purpleRibbonVariants: Variants = {
  idle: { opacity: 1, filter: "brightness(1)" },
  loading: {
    opacity: [0, 1],
    x: [34, 0],
    y: [-18, 0],
    rotate: [14, 0],
    transition: { duration: 0.28, ease: ease.emerge, delay: 0.78 },
  },
  thinking: { opacity: [0.85, 1, 0.85], transition: { duration: duration.thinkingPulse, repeat: Infinity, ease: ease.ambient, delay: 0.15 } },
  transition: { opacity: 0, x: 18, y: 10, transition: { duration: duration.transitionBreak, ease: ease.linearSnap } },
  success: { opacity: 1, filter: "brightness(1.15)" },
  error: { opacity: 1, x: [0, 5, -3, 0], transition: { duration: duration.error, ease: ease.linearSnap } },
  celebration: { opacity: 1, filter: "brightness(1.2)" },
  achievement: { opacity: 1, filter: "brightness(1.1)" },
  hidden: { opacity: 0 },
};

const starVariants: Variants = {
  idle: {
    opacity: [0.75, 1, 0.75],
    scale: [1, 1.12, 1],
    transition: { duration: duration.starTwinkle, ease: ease.ambient, repeat: Infinity },
  },
  loading: {
    opacity: [0, 1],
    scale: [0.2, 1.3, 1],
    transition: { duration: 0.2, ease: ease.emerge },
  },
  thinking: {
    opacity: [0.6, 1, 0.6],
    scale: [0.95, 1.15, 0.95],
    transition: { duration: duration.thinkingPulse, ease: ease.ambient, repeat: Infinity },
  },
  transition: { opacity: [1, 0.4, 0], scale: [1, 1.6, 0.3], transition: { duration: duration.transitionBreak, ease: ease.linearSnap } },
  success: { opacity: 1, scale: [1, 1.5, 1], transition: { duration: duration.success, ease: ease.appleOut } },
  error: { opacity: [1, 0.4, 1], scale: 1, transition: { duration: duration.error, ease: ease.linearSnap } },
  celebration: { opacity: 1, scale: [1, 1.6, 1], transition: { duration: duration.celebration, ease: ease.appleOut } },
  achievement: { opacity: 1, scale: [1, 1.3, 1], transition: { duration: duration.achievement, ease: ease.appleOut } },
  hidden: { opacity: 0 },
};

const tailVariants: Variants = {
  idle: { opacity: 0.9, pathLength: 1 },
  loading: { opacity: [0, 1], pathLength: [0, 1], transition: { duration: 0.3, delay: 0.9, ease: ease.emerge } },
  thinking: { opacity: 0.9, pathLength: 1 },
  transition: { opacity: 0, pathLength: 1, transition: { duration: duration.transitionBreak, ease: ease.linearSnap } },
  success: { opacity: 1, pathLength: 1 },
  error: { opacity: 0.9, pathLength: 1 },
  celebration: { opacity: 1, pathLength: 1 },
  achievement: { opacity: 1, pathLength: 1 },
  hidden: { opacity: 0 },
};

/* Reduced-motion variants: opacity/color changes only. No
 * transform, no path animation, no repeat loops. This is what
 * ships when the OS "reduce motion" preference is on — it is not
 * an afterthought bolted onto the expressive variants above. */
const reducedContainerVariants: Variants = {
  idle: { opacity: 1, transition: reducedTransition },
  loading: { opacity: 1, transition: reducedTransition },
  thinking: { opacity: 1, transition: reducedTransition },
  transition: { opacity: 0.5, transition: reducedTransition },
  success: { opacity: 1, transition: reducedTransition },
  error: { opacity: 1, transition: reducedTransition },
  celebration: { opacity: 1, transition: reducedTransition },
  achievement: { opacity: 1, transition: reducedTransition },
  hidden: { opacity: 0, transition: reducedTransition },
};

const reducedPartVariants: Variants = {
  idle: { opacity: 1, transition: reducedTransition },
  loading: { opacity: 1, transition: reducedTransition },
  thinking: { opacity: 1, transition: reducedTransition },
  transition: { opacity: 0.4, transition: reducedTransition },
  success: { opacity: 1, filter: "brightness(1.15)", transition: reducedTransition },
  error: { opacity: 1, filter: "brightness(0.85)", transition: reducedTransition },
  celebration: { opacity: 1, filter: "brightness(1.15)", transition: reducedTransition },
  achievement: { opacity: 1, filter: "brightness(1.1)", transition: reducedTransition },
  hidden: { opacity: 0, transition: reducedTransition },
};

export function EvolutionGlyph({
  state = "idle",
  size = 96,
  className,
  ariaLabel,
  onStateComplete,
  layoutId,
  forceReducedMotion,
}: EvolutionGlyphProps) {
  const reducedMotion = useReducedMotionPreference(forceReducedMotion);

  // One-shot states resolve back to idle once their transition-level
  // timeout elapses. The parent owns `state`, so we just notify.
  useEffect(() => {
    const oneShotDurations: Partial<Record<string, number>> = {
      success: duration.success,
      error: duration.error,
      celebration: duration.celebration,
      achievement: duration.achievement,
      transition: duration.transitionBreak + duration.transitionTravel + duration.transitionReassemble,
    };
    const d = oneShotDurations[state];
    if (!d) return;
    const timer = setTimeout(() => onStateComplete?.(state), d * 1000);
    return () => clearTimeout(timer);
  }, [state, onStateComplete]);

  const cVariants = reducedMotion ? reducedContainerVariants : containerVariants;
  const showGlow = state !== "hidden";

  const glowColor =
    state === "error"
      ? glyphColor.errorEmber
      : state === "achievement"
      ? glyphColor.achievementGold
      : glyphColor.indigo;

  return (
    <motion.div
      layoutId={layoutId}
      className={className}
      role={ariaLabel ? "img" : undefined}
      aria-label={ariaLabel}
      aria-hidden={ariaLabel ? undefined : true}
      style={{
        position: "relative",
        width: size,
        height: size,
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        willChange: "transform",
      }}
      variants={cVariants}
      animate={state}
      initial={false}
    >
      <GlowLayer
        active={showGlow}
        color={glowColor}
        size={size * 1.5}
        intensity={state === "thinking" ? 0.7 : 0.5}
        reducedMotion={reducedMotion}
      />

      <ParticleSystem state={state} reducedMotion={reducedMotion} radius={size * 0.55} />

      <svg
        viewBox={`0 0 ${VIEWBOX_SIZE} ${VIEWBOX_SIZE}`}
        width={size}
        height={size}
        style={{ position: "relative", zIndex: 1 }}
      >
        <defs>
          <linearGradient id="evo-blue" x1="0%" y1="0%" x2="60%" y2="100%">
            <stop offset="0%" stopColor={glyphColor.cyan} />
            <stop offset="100%" stopColor={glyphColor.blue} />
          </linearGradient>
          <linearGradient id="evo-purple" x1="20%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={glyphColor.indigo} />
            <stop offset="55%" stopColor={glyphColor.violet} />
            <stop offset="100%" stopColor={glyphColor.orchid} />
          </linearGradient>
          <radialGradient id="evo-star" cx="50%" cy="50%" r="60%">
            <stop offset="0%" stopColor={glyphColor.starCore} />
            <stop offset="100%" stopColor={glyphColor.starGlow} />
          </radialGradient>
        </defs>

        <motion.path
          d={BLUE_RIBBON_PATH}
          fill="url(#evo-blue)"
          variants={reducedMotion ? reducedPartVariants : blueRibbonVariants}
          animate={state}
          initial={false}
          style={{ transformOrigin: "120px 120px" }}
        />
        <motion.path
          d={TOP_FOLD_PATH}
          fill={glyphColor.cyan}
          opacity={0.75}
          variants={reducedMotion ? reducedPartVariants : blueRibbonVariants}
          animate={state}
          initial={false}
          style={{ transformOrigin: "120px 40px" }}
        />
        <motion.path
          d={PURPLE_RIBBON_PATH}
          fill="url(#evo-purple)"
          variants={reducedMotion ? reducedPartVariants : purpleRibbonVariants}
          animate={state}
          initial={false}
          style={{ transformOrigin: "120px 120px" }}
        />
        <motion.path
          d={TAIL_FLOURISH_PATH}
          fill="none"
          stroke="url(#evo-purple)"
          strokeWidth={22}
          strokeLinecap="round"
          variants={reducedMotion ? reducedPartVariants : tailVariants}
          animate={state}
          initial={false}
        />
        <motion.path
          d={STAR_PATH}
          fill="url(#evo-star)"
          variants={reducedMotion ? reducedPartVariants : starVariants}
          animate={state}
          initial={false}
          style={{ transformOrigin: "120px 120px" }}
        />
      </svg>
    </motion.div>
  );
}

export default EvolutionGlyph;
