"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { duration, ease } from "../lib/motion-tokens";
import { useReducedMotionPreference } from "../hooks/useReducedMotionPreference";
import { EvolutionGlyph } from "./EvolutionGlyph";
import { EVOLUTION_LAYOUT_ID } from "./EvolutionNavbarLogo";

interface EvolutionTransitionProps {
  /** Bump this (e.g. to the route pathname) whenever navigation
   *  happens — the transition triggers on change, not on mount. */
  routeKey: string;
  children: React.ReactNode;
  glyphSize?: number;
}

/**
 * EvolutionTransition
 * ------------------------------------------------------------------
 * Wrap page content with this. On `routeKey` change: the navbar
 * glyph (same EVOLUTION_LAYOUT_ID) breaks into particles, travels,
 * reassembles, and only then does the incoming page fade in — so
 * the page never appears "under" an unfinished animation.
 *
 * The glyph shown here during the break/travel is a `transition`
 * state instance; because it shares the layoutId with
 * EvolutionNavbarLogo, Framer's layout animation handles the
 * "travel" implicitly — this component only has to sequence the
 * break → hold → reassemble → reveal timing.
 */
export function EvolutionTransition({ routeKey, children, glyphSize = 32 }: EvolutionTransitionProps) {
  const reducedMotion = useReducedMotionPreference();
  const [stage, setStage] = useState<"idle" | "breaking" | "reassembling">("idle");
  const [displayedKey, setDisplayedKey] = useState(routeKey);

  useEffect(() => {
    if (routeKey === displayedKey) return;

    if (reducedMotion) {
      // Straight crossfade, no particle break — content changes
      // almost immediately, respecting the no-motion preference.
      setDisplayedKey(routeKey);
      return;
    }

    setStage("breaking");
    const t1 = setTimeout(() => setStage("reassembling"), duration.transitionBreak * 1000);
    const t2 = setTimeout(
      () => {
        setDisplayedKey(routeKey);
        setStage("idle");
      },
      (duration.transitionBreak + duration.transitionTravel) * 1000
    );
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [routeKey]);

  return (
    <>
      <AnimatePresence>
        {stage !== "idle" && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            style={{
              position: "fixed",
              inset: 0,
              zIndex: 9998,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              pointerEvents: "none",
            }}
          >
            <EvolutionGlyph state="transition" size={glyphSize * 1.8} layoutId={EVOLUTION_LAYOUT_ID} />
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence mode="wait">
        <motion.div
          key={displayedKey}
          initial={{ opacity: 0 }}
          animate={{ opacity: stage === "idle" ? 1 : 0 }}
          transition={{ duration: duration.transitionReassemble, ease: ease.appleOut }}
          aria-hidden={stage !== "idle"}
          style={{ pointerEvents: stage === "idle" ? "auto" : "none" }}
        >
          {children}
        </motion.div>
      </AnimatePresence>
    </>
  );
}

export default EvolutionTransition;
