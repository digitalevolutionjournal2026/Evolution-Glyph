"use client";

import { EvolutionGlyph } from "./EvolutionGlyph";
import type { GlyphState } from "../lib/types";

export const EVOLUTION_LAYOUT_ID = "evolution-glyph-mark";

interface EvolutionNavbarLogoProps {
  /** True while the app has an in-flight AI response — drives the
   *  "thinking" micro-state so the same mark doubles as a status
   *  indicator, per the micro-interactions brief. */
  isThinking?: boolean;
  size?: number;
  onClick?: () => void;
  className?: string;
}

/**
 * EvolutionNavbarLogo
 * ------------------------------------------------------------------
 * The permanent home for the glyph once EvolutionSplash / the
 * page-load sequence finishes. Shares EVOLUTION_LAYOUT_ID with
 * EvolutionLoader and EvolutionTransition so Framer Motion performs
 * an automatic shared-element (FLIP) animation between them — this
 * is how the spec's "it never disappears, it transforms, it moves
 * smoothly into navbar position" requirement is actually satisfied,
 * rather than faked with a manually-tweened fade/move.
 */
export function EvolutionNavbarLogo({ isThinking = false, size = 32, onClick, className }: EvolutionNavbarLogoProps) {
  const state: GlyphState = isThinking ? "thinking" : "idle";

  return (
    <button
      type="button"
      onClick={onClick}
      className={className}
      aria-label="Digital Evolution Journal home"
      style={{
        background: "none",
        border: "none",
        padding: 0,
        cursor: onClick ? "pointer" : "default",
        display: "inline-flex",
      }}
    >
      <EvolutionGlyph state={state} size={size} layoutId={EVOLUTION_LAYOUT_ID} />
    </button>
  );
}

export default EvolutionNavbarLogo;
