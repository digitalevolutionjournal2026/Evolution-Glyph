"use client";

import { useMemo } from "react";
import { motion, type Variants } from "framer-motion";
import { duration, ease, glyphColor, spring } from "../lib/motion-tokens";
import type { ParticleSystemProps } from "../lib/types";

interface Particle {
  id: number;
  angle: number; // radians, position around the ring
  distance: number; // px from center at rest
  size: number;
  color: string;
  delay: number;
}

const PARTICLE_COLORS = [glyphColor.cyan, glyphColor.indigo, glyphColor.orchid, glyphColor.starGlow];

function buildParticles(count: number, radius: number): Particle[] {
  return Array.from({ length: count }, (_, i) => {
    const angle = (i / count) * Math.PI * 2 + (i % 2 === 0 ? 0.18 : -0.12);
    return {
      id: i,
      angle,
      distance: radius * (0.72 + (i % 3) * 0.14),
      size: 3 + (i % 3),
      color: PARTICLE_COLORS[i % PARTICLE_COLORS.length],
      delay: (i / count) * 0.5,
    };
  });
}

/**
 * ParticleSystem
 * ------------------------------------------------------------------
 * Renders as an absolutely-positioned overlay of small circles
 * around the glyph's center. Two different GPU-cheap strategies
 * depending on state:
 *
 *  - orbit states (thinking / loading-orbit): a single wrapping
 *    <motion.g>-equivalent div is rotated continuously. Rotating
 *    one parent transform is far cheaper than animating N
 *    individual (x, y) pairs every frame.
 *  - burst/converge states (loading-assembly, celebration,
 *    transition): each particle animates its own transform once
 *    (not looped), which is cheap because it isn't continuous.
 *
 * Particle count is intentionally small (default 8) — this is an
 * ambient accent, never a fireworks display.
 */
export function ParticleSystem({ state, count = 8, radius = 64, reducedMotion = false }: ParticleSystemProps) {
  const particles = useMemo(() => buildParticles(count, radius), [count, radius]);

  const isOrbiting = state === "thinking" || state === "loading";
  const isBursting = state === "celebration" || state === "transition";
  const isConverging = state === "loading";

  if (reducedMotion) {
    // Reduced motion: show a faint static ring, no orbit/burst.
    if (!isOrbiting && !isBursting) return null;
    return (
      <div style={{ position: "absolute", inset: 0 }} aria-hidden>
        {particles.slice(0, 4).map((p) => (
          <div
            key={p.id}
            style={{
              position: "absolute",
              left: "50%",
              top: "50%",
              width: p.size,
              height: p.size,
              borderRadius: "50%",
              background: p.color,
              opacity: 0.35,
              transform: `translate(-50%, -50%) translate(${Math.cos(p.angle) * p.distance}px, ${
                Math.sin(p.angle) * p.distance
              }px)`,
            }}
          />
        ))}
      </div>
    );
  }

  const particleVariants: Variants = {
    thinking: (p: Particle) => ({
      opacity: [0.25, 0.85, 0.25],
      scale: [0.7, 1, 0.7],
      transition: { duration: 2.2, repeat: Infinity, ease: ease.ambient, delay: p.delay },
    }),
    loading: (p: Particle) => ({
      // Converge from scattered start toward resting orbit distance.
      opacity: [0, 1, 1],
      scale: [0.3, 1.1, 1],
      transition: { duration: 0.5, ease: ease.emerge, delay: p.delay * 0.4 },
    }),
    celebration: (p: Particle) => ({
      opacity: [1, 1, 0],
      scale: [0.6, 1.3, 0.4],
      x: Math.cos(p.angle) * radius * 1.8,
      y: Math.sin(p.angle) * radius * 1.8,
      transition: { ...spring.bouncy, duration: duration.celebration, delay: p.delay * 0.3 },
    }),
    transition: (p: Particle) => ({
      opacity: [1, 0],
      scale: [1, 0.3],
      x: Math.cos(p.angle) * radius * 2.4,
      y: Math.sin(p.angle) * radius * 2.4,
      transition: { duration: duration.transitionTravel, ease: ease.linearSnap },
    }),
    idle: () => ({ opacity: 0 }),
    hidden: () => ({ opacity: 0 }),
  };

  const showOrbitWrapper = isOrbiting;

  // Particles are an accent for specific states only. Without this
  // guard the lookup below silently fell back to the "thinking" key
  // for idle/success/error/achievement too, so the glyph appeared
  // to be faintly "thinking" all the time — the opposite of the
  // calm idle state the brief asks for.
  if (!isOrbiting && !isBursting && !isConverging) return null;

  return (
    <div style={{ position: "absolute", inset: 0, pointerEvents: "none" }} aria-hidden>
      <motion.div
        style={{ position: "absolute", inset: 0, willChange: "transform" }}
        animate={showOrbitWrapper ? { rotate: 360 } : { rotate: 0 }}
        transition={
          showOrbitWrapper
            ? { duration: duration.thinkingOrbit, ease: "linear", repeat: Infinity }
            : { duration: 0 }
        }
      >
        {particles.map((p) => (
          <motion.div
            key={p.id}
            custom={p}
            initial={{ opacity: 0 }}
            animate={particleVariants[isConverging ? "loading" : isBursting ? state : "thinking"](p)}
            style={{
              position: "absolute",
              left: "50%",
              top: "50%",
              width: p.size,
              height: p.size,
              marginLeft: -p.size / 2,
              marginTop: -p.size / 2,
              borderRadius: "50%",
              background: p.color,
              boxShadow: `0 0 6px ${p.color}`,
              transform: `translate(${Math.cos(p.angle) * p.distance}px, ${Math.sin(p.angle) * p.distance}px)`,
              willChange: "transform, opacity",
            }}
          />
        ))}
      </motion.div>
    </div>
  );
}
