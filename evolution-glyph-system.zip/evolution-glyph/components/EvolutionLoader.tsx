"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ease, glyphColor, loadingTimeline } from "../lib/motion-tokens";
import { useReducedMotionPreference } from "../hooks/useReducedMotionPreference";
import { EvolutionGlyph } from "./EvolutionGlyph";
import { EVOLUTION_LAYOUT_ID } from "./EvolutionNavbarLogo";

type LoaderPhase = "spark" | "growing" | "orbiting" | "assembling" | "locking" | "pulsing" | "done";

const PHASE_AT_MS: [number, LoaderPhase][] = [
  [loadingTimeline.sparkAppear[0], "spark"],
  [loadingTimeline.sparkGrow[0], "growing"],
  [loadingTimeline.particlesOrbit[0], "orbiting"],
  [loadingTimeline.segmentsFlyIn[0], "assembling"],
  [loadingTimeline.glyphLock[0], "locking"],
  [loadingTimeline.glowPulse[0], "pulsing"],
  [loadingTimeline.handoff, "done"],
];

interface EvolutionLoaderProps {
  size?: number;
  onComplete?: () => void;
  forceReducedMotion?: boolean;
}

/**
 * EvolutionLoader
 * ------------------------------------------------------------------
 * Runs the exact narrative from the brief:
 *   Spark → Awareness → Reflection → Growth → Transformation →
 *   Evolution Glyph → Navbar Logo
 *
 * Phases 1–3 (spark / growing / orbiting) are rendered as a
 * standalone spark + particle field, because the full glyph
 * geometry has nothing to show yet — "awareness" and "reflection"
 * are represented by the particle field's orbit widening and
 * slowing, not by the glyph itself. Phases 4–6 hand off to
 * <EvolutionGlyph state="loading" /> for the fly-in/lock/pulse,
 * which shares EVOLUTION_LAYOUT_ID with the navbar target so the
 * final move is a real layout animation, not a fade substitute.
 *
 * Reduced motion: collapses straight to a single 250ms crossfade
 * from spark to the resting glyph. The story is still legible
 * (spark → mark) without any motion the user asked to avoid.
 */
export function EvolutionLoader({ size = 88, onComplete, forceReducedMotion }: EvolutionLoaderProps) {
  const reducedMotion = useReducedMotionPreference(forceReducedMotion);
  const [phase, setPhase] = useState<LoaderPhase>("spark");

  useEffect(() => {
    if (reducedMotion) {
      const t = setTimeout(() => {
        setPhase("done");
        onComplete?.();
      }, 250);
      return () => clearTimeout(t);
    }

    const timers = PHASE_AT_MS.map(([ms, phaseName]) =>
      setTimeout(() => {
        setPhase(phaseName);
        if (phaseName === "done") onComplete?.();
      }, ms)
    );
    return () => timers.forEach(clearTimeout);
  }, [reducedMotion, onComplete]);

  if (reducedMotion) {
    return (
      <div style={{ position: "relative", width: size, height: size }}>
        <AnimatePresence mode="wait">
          {phase !== "done" ? (
            <motion.div
              key="spark"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.25 }}
              style={{
                position: "absolute",
                inset: 0,
                margin: "auto",
                width: 10,
                height: 10,
                borderRadius: "50%",
                background: glyphColor.starCore,
              }}
            />
          ) : (
            <motion.div key="glyph" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.25 }}>
              <EvolutionGlyph state="idle" size={size} layoutId={EVOLUTION_LAYOUT_ID} forceReducedMotion />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  }

  const showSpark = phase === "spark" || phase === "growing";
  const showGlyph = phase === "assembling" || phase === "locking" || phase === "pulsing" || phase === "done";

  return (
    <div style={{ position: "relative", width: size, height: size, display: "flex", alignItems: "center", justifyContent: "center" }}>
      <AnimatePresence>
        {showSpark && (
          <motion.div
            key="spark"
            initial={{ opacity: 0, scale: 0.2 }}
            animate={{
              opacity: 1,
              scale: phase === "growing" ? [0.5, 1.4] : 0.5,
              boxShadow: `0 0 ${phase === "growing" ? 30 : 12}px ${glyphColor.starGlow}`,
            }}
            exit={{ opacity: 0, scale: 1.8, transition: { duration: 0.15, ease: ease.linearSnap } }}
            transition={{ duration: 0.2, ease: ease.emerge }}
            style={{
              position: "absolute",
              width: 10,
              height: 10,
              borderRadius: "50%",
              background: glyphColor.starCore,
            }}
          />
        )}
      </AnimatePresence>

      {/* Orbiting particles = "awareness" widening into "reflection". */}
      <AnimatePresence>
        {(phase === "orbiting" || phase === "assembling") && (
          <motion.div
            key="orbit-field"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1, rotate: 180 }}
            exit={{ opacity: 0, transition: { duration: 0.15 } }}
            transition={{ duration: 0.3, ease: "linear" }}
            style={{ position: "absolute", inset: 0 }}
          >
            {[0, 1, 2, 3, 4].map((i) => {
              const angle = (i / 5) * Math.PI * 2;
              const r = size * 0.32;
              return (
                <motion.div
                  key={i}
                  animate={{ opacity: [0.4, 1, 0.4] }}
                  transition={{ duration: 0.6, repeat: Infinity, delay: i * 0.05 }}
                  style={{
                    position: "absolute",
                    left: "50%",
                    top: "50%",
                    width: 4,
                    height: 4,
                    borderRadius: "50%",
                    background: i % 2 === 0 ? glyphColor.cyan : glyphColor.orchid,
                    transform: `translate(-50%,-50%) translate(${Math.cos(angle) * r}px, ${Math.sin(angle) * r}px)`,
                  }}
                />
              );
            })}
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showGlyph && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.1 }}>
            <EvolutionGlyph
              state={phase === "pulsing" || phase === "done" ? "success" : "loading"}
              size={size}
              layoutId={EVOLUTION_LAYOUT_ID}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default EvolutionLoader;
