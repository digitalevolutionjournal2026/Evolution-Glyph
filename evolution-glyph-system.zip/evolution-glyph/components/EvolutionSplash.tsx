"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ease } from "../lib/motion-tokens";
import { EvolutionLoader } from "./EvolutionLoader";

interface EvolutionSplashProps {
  /** Called once the loader finishes AND the splash chrome has
   *  fully faded — safe point to mount the real app shell. */
  onComplete?: () => void;
  children?: React.ReactNode;
}

/**
 * EvolutionSplash
 * ------------------------------------------------------------------
 * First-paint screen. Owns the dark stage the glyph performs on;
 * the glyph itself is entirely EvolutionLoader's responsibility so
 * the same loader can also be reused inline (e.g. inside a modal)
 * without dragging a full-bleed background along with it.
 */
export function EvolutionSplash({ onComplete, children }: EvolutionSplashProps) {
  const [loaderDone, setLoaderDone] = useState(false);

  return (
    <AnimatePresence onExitComplete={onComplete}>
      {!loaderDone && (
        <motion.div
          key="splash"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0, transition: { duration: 0.4, ease: ease.appleOut } }}
          style={{
            position: "fixed",
            inset: 0,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            background: "radial-gradient(circle at 50% 42%, #0B0E1A 0%, #05060A 70%)",
            zIndex: 9999,
          }}
        >
          <EvolutionLoader onComplete={() => setLoaderDone(true)} />
          {children}
        </motion.div>
      )}
    </AnimatePresence>
  );
}

export default EvolutionSplash;
