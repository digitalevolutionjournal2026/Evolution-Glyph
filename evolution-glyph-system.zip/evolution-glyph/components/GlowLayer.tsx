"use client";

import { motion } from "framer-motion";
import { duration, ease, reducedTransition } from "../lib/motion-tokens";
import type { GlowLayerProps } from "../lib/types";

/**
 * GlowLayer
 * ------------------------------------------------------------------
 * A single radial-gradient glow, absolutely centered behind
 * whatever it's paired with. Animates only `opacity` and
 * `transform: scale()` — both are GPU-composited, so this never
 * touches layout or paint on the surrounding tree.
 *
 * Deliberately its own component (rather than inline in the
 * glyph) because the same "ambient breathing glow" is reused
 * behind buttons, cards and AI-response affordances per the
 * micro-interaction brief — one implementation, one feel.
 */
export function GlowLayer({ active, color, size, intensity = 0.55, reducedMotion = false }: GlowLayerProps) {
  if (!active) return null;

  if (reducedMotion) {
    // Static presence only — no pulsing, no scale change.
    return (
      <div
        aria-hidden
        style={{
          position: "absolute",
          inset: 0,
          margin: "auto",
          width: size,
          height: size,
          background: `radial-gradient(circle, ${color} 0%, transparent 70%)`,
          opacity: intensity * 0.6,
          pointerEvents: "none",
        }}
      />
    );
  }

  return (
    <motion.div
      aria-hidden
      style={{
        position: "absolute",
        inset: 0,
        margin: "auto",
        width: size,
        height: size,
        background: `radial-gradient(circle, ${color} 0%, transparent 70%)`,
        pointerEvents: "none",
        willChange: "transform, opacity",
      }}
      initial={{ opacity: 0, scale: 0.85 }}
      animate={{
        opacity: [intensity * 0.35, intensity, intensity * 0.35],
        scale: [0.9, 1.08, 0.9],
      }}
      transition={{
        duration: duration.glowPulseIdle,
        ease: ease.ambient,
        repeat: Infinity,
        repeatType: "loop",
      }}
      exit={{ opacity: 0, scale: 0.85, transition: reducedTransition }}
    />
  );
}
