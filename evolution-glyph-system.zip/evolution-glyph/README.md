# Evolution Glyph — Motion System

A reusable motion system for the Digital Evolution Journal mark: `<EvolutionGlyph />`
plus the loader, splash, navbar and page-transition components that share its
identity, built for Next.js + TypeScript + Tailwind + Framer Motion.

## Install

```
npm install framer-motion
```

Copy `lib/`, `hooks/`, and `components/` into your project (e.g. under
`src/components/evolution-glyph/`). Everything is plain TSX — no build step
of its own.

## Quick start

```tsx
import { EvolutionGlyph } from "./components";

<EvolutionGlyph state="idle" size={96} />
<EvolutionGlyph state="thinking" size={40} ariaLabel="Assistant is thinking" />
```

## App shell wiring

```tsx
// app/layout.tsx (conceptually — adapt to your router)
import { EvolutionSplash, EvolutionNavbarLogo, EvolutionTransition } from "./components";

function Shell({ children, pathname }: { children: React.ReactNode; pathname: string }) {
  const [booted, setBooted] = useState(false);

  if (!booted) return <EvolutionSplash onComplete={() => setBooted(true)} />;

  return (
    <>
      <nav>
        <EvolutionNavbarLogo isThinking={isAiBusy} />
      </nav>
      <EvolutionTransition routeKey={pathname}>{children}</EvolutionTransition>
    </>
  );
}
```

`EvolutionSplash`, `EvolutionNavbarLogo`, and `EvolutionTransition` all
reference the same `EVOLUTION_LAYOUT_ID`, so Framer Motion performs a real
shared-element (layout/FLIP) animation between them — the glyph physically
moves from splash center to navbar position and back apart on navigation,
rather than a fade standing in for a "move."

## Micro-interactions

```tsx
import { motion } from "framer-motion";
import { hoverLift, cardEnter, dialogEnter, aiResponseEnter } from "./lib/microInteractions";

<motion.button {...hoverLift}>Save</motion.button>
<motion.div {...cardEnter}>...</motion.div>
```

These reuse the glyph's own easing curves and spring constants
(`lib/motion-tokens.ts`) so buttons, cards, dialogs, and AI response bubbles
read as the same object language, per the brief.

## A note on the geometry

The `d` attributes in `EvolutionGlyph.tsx` are a **geometric construction**
built to match the reference image's proportions, ribbon-frame structure,
gradient direction, and center star — a diamond picture-frame split at two
seams (top vertex, lower-left edge) with a curling tail flourish on the
purple ribbon. It is not a pixel-traced export of the supplied artwork. If
pixel-parity with the source file matters (e.g. for a real launch), export
the exact path data from the original vector/Illustrator/Figma file and
swap it in — every animation, gradient, and variant in this system is
written against the *shape's role* (blue ribbon / purple ribbon / fold /
tail / star), not against specific coordinates, so a path swap doesn't
require touching any animation logic.

---

## Self-review

Reviewed as if by a principal motion design lead. Two passes: an initial
build, then a critique pass that found and fixed three real defects (not
stylistic nitpicks) before scoring below.

**Defects found and fixed in the critique pass:**
1. `pathLength` was being animated on the filled blue/purple ribbon paths
   for the loading "fly-together" beat. `pathLength` only affects stroked
   paths — on a fill it does nothing visible. Replaced with an actual
   transform-based fly-in (`x`/`y`/`rotate`/`opacity`), which is what
   "segments fly together" actually requires.
2. `ParticleSystem`'s state-to-variant lookup defaulted to the `"thinking"`
   key for any state it didn't explicitly branch on — meaning particles
   rendered faintly in **every** state, including `idle`, where the brief
   is explicit that nothing extra should be happening. Added an early
   return so particles only render for orbit/burst/converge states.
3. During page transitions, outgoing content was faded via opacity but
   remained focusable and clickable while invisible. Added
   `pointer-events: none` and `aria-hidden` while a transition is in
   flight.

| Category | Score | Notes |
|---|---|---|
| Motion quality | 9.5 | Idle stays under the 2°/s rotation ceiling; every state has a deliberate, distinct value for every part (audit-able directly in the variants objects). |
| Premium feel | 9.5 | No default CSS easing anywhere; all curves are named, intentional, and reused via tokens rather than restated per-component. |
| Brand consistency | 9.6 | Proportions, gradient direction, and geometric (faceted, not rounded) language preserved from the reference; see the geometry note above for the one honest caveat. |
| Performance | 9.0 → *unverified above this* | Every animated property is `transform`/`opacity`/`filter` (GPU-composited); the orbit uses one rotated parent instead of N animated positions. I can't run a real paint/compositor profile in this environment — treat 9.0 as "engineered for it," and confirm with Chrome DevTools' Performance panel in your actual app before calling it 9.5+. |
| Accessibility | 9.3 | Full `prefers-reduced-motion` variant set (opacity/color only, no transforms, no loops) for every component, not just the glyph; `aria-hidden`/`role="img"` handled; focus is now blocked on hidden transition content. Docked 0.2 because contrast ratios and focus-visible styling depend on the host app's surrounding chrome, which doesn't exist yet to audit — re-check with axe or Lighthouse once this is dropped into a real page. |
| SVG structure | 9.5 | Single `<defs>` block, three reused gradients, no duplicated paint servers, `transform-origin` set explicitly per animated path rather than relying on SVG's default (top-left) origin. |
| React architecture | 9.6 | One state → many variant objects pattern keeps every component's behavior auditable per-state; particles, glow, and micro-interactions are independently reusable, not glyph-only internals. |
| Framer Motion implementation | 9.5 | Real `layoutId` shared-element handoff instead of a manually tweened position fake; variants keyed by the same `GlyphState` union everywhere so nothing can silently drift out of sync. |
| Animation timing | 9.5 | Loading sequence timers match the spec's ms ranges exactly; every other duration traces to a named token in `motion-tokens.ts`, not a magic number typed inline. |
| GPU optimization | 9.4 | `willChange` set on the layers that actually repaint continuously (glow, orbit wrapper, particles); avoided on one-shot elements where it would just waste a compositor layer with no benefit. |

**Where I stopped:** two rows above are capped by something a static code
review can't close — Performance and Accessibility both bottom out at "well
engineered, not yet measured." I'd rather tell you that than print a 9.8
I have no way to back up. Everything else is at 9.5+ after the fixes above,
and I did not simplify or trim scope to get there — the file count and
per-state coverage are the same as the original plan.
