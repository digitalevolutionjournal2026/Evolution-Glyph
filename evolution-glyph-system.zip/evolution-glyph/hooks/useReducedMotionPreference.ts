"use client";

import { useEffect, useState } from "react";

/**
 * useReducedMotionPreference
 * ------------------------------------------------------------------
 * Framer Motion's own `useReducedMotion` hook reads the media query
 * once on mount in most versions and doesn't reliably re-render
 * everywhere it's consumed via context. Since accessibility here is
 * load-bearing — not a nice-to-have — we track the media query
 * directly and update live if the user changes the OS setting
 * while the app is open.
 */
export function useReducedMotionPreference(forceReducedMotion?: boolean): boolean {
  const [prefersReduced, setPrefersReduced] = useState<boolean>(false);

  useEffect(() => {
    if (typeof window === "undefined" || !window.matchMedia) return;

    const query = window.matchMedia("(prefers-reduced-motion: reduce)");
    setPrefersReduced(query.matches);

    const listener = (event: MediaQueryListEvent) => setPrefersReduced(event.matches);

    // addEventListener is preferred; addListener is the Safari <14 fallback.
    if (query.addEventListener) {
      query.addEventListener("change", listener);
      return () => query.removeEventListener("change", listener);
    } else {
      // eslint-disable-next-line deprecation/deprecation
      query.addListener(listener);
      // eslint-disable-next-line deprecation/deprecation
      return () => query.removeListener(listener);
    }
  }, []);

  return forceReducedMotion ?? prefersReduced;
}
